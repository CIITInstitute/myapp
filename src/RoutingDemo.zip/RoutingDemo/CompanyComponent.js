import React from "react";
export const Company=()=>{
    return(
        <div>
            <h2>About Company</h2>
        </div>
    )
}