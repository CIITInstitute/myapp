import React from "react";
export const Staff=()=>{
    return(
        <div>
            <h2>About Staff</h2>
        </div>
    )
}